# Frontend Setup

```bash
cd frontend
npm install
npm run dev
```

Access at http://localhost:3000
