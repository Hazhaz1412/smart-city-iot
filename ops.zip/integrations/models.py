from django.db import models


# This app mainly uses Celery tasks and doesn't need database models
# All data is stored in observations app
